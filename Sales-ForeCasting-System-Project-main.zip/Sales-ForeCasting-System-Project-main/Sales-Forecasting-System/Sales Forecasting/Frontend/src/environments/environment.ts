export const environment = {
    production: false,
    firebase : {
        apiKey: "AIzaSyCMW4YqXflZGSV0m0dk9TFAva1dT-kMpI4",
        authDomain: "sales-predict-auth.firebaseapp.com",
        projectId: "sales-predict-auth",
        storageBucket: "sales-predict-auth.appspot.com",
        messagingSenderId: "62267757242",
        appId: "1:62267757242:web:a2740de87d1b2db8482883"
    }
  };
  