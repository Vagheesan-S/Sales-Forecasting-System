# Sales-Forecasting--Kaar-Technologies
Sales Forecasting using prophet ( Angular , Firebase , Flask , Machine learning and MongoDB) - Kaar Technologies


contact (vasantheeswaran3108@gmail.com) for help 
